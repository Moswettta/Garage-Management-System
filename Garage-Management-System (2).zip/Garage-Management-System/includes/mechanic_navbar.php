<nav class="navbar navbar-expand-lg navbar-dark" style="background:#047a94">
  <div class="container-fluid">
    <a class="navbar-brand" href="index.php">Garage ms</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarText" style="margin-left: 140px;">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item hvr-underline">
          <a class="nav-link active" href="mechanic_dashboard.php">Home</a>
        </li>
      </ul>


  <li class="nav-item">
            <a href ="mechaniclogin.php"style="color: red; font-weight: 600;">LOG OUT</a>
          </li>


      <?php if(isset($_SESSION['mname'])) : ?>
        <span class="navbar-text">
          <i class="far fa-user"></i>&nbsp;<?php echo $_SESSION['mname']; ?>
        </span>
       
      <?php endif ?>
      <span class="navbar-text">
        Need Help? Call 07458271 
      </span>
    </div>
  </div>
</nav>
