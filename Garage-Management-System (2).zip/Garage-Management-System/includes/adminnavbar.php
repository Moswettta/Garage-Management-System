
<?php error_reporting(1)
?>



<?php
session_start(); // Starting the session

// Check if the logout parameter is set in the URL
if(isset($_GET['logout']) && $_GET['logout'] == 1) {
    // Unset all of the session variables
    $_SESSION = array();

    // Destroy the session.
    session_destroy();

    // Redirect to the login page or any other page after logout
    header("Location: login.php"); // Change "login.php" to your desired page
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Garage Management System</title>
  <!-- Add your CSS and JavaScript includes here -->
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark" style="background:#047a94">
  <div class="container-fluid">
    <a class="navbar-brand" href="index.php">Garage Management System</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item hvr-underline">
          <a class="nav-link active" href="admin.php">Home</a>
        </li>
      </ul>
      <ul class="navbar-nav">
        <li class="nav-item dropdown">
          <?php if(!isset($_SESSION['ename']) && !isset($_SESSION['mname'])): ?>
            <!-- If user is not logged in, show login link -->
            <a class="nav-link active hvr-underline" onclick="document.getElementById('id01').style.display='block'" style="cursor: pointer;">LOG IN</a>
          <?php endif; ?>
          <?php if(isset($_SESSION['ename'])): ?>
            <!-- If user is logged in, show username and logout option -->
            <a class="nav-link active dropdown-toggle hvr-underline" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              <i class="far fa-user"></i>&nbsp;<?php echo $_SESSION['ename']; ?>
            </a>
            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdownMenuLink">
              <li><a class="dropdown-item" href="admin.php?logout=1" style="color: red;font-weight:600;">LOG OUT</a></li>
            </ul>
          <?php endif; ?>
        </li>
      </ul>
    </div>
  </div>
</nav>

<!-- Your HTML content here -->

<!-- Example modal for login -->
<div id="id01" class="modal">
  <div class="modal-content">
    <!-- Login form content here -->
  </div>
</div>

<!-- Add your JavaScript includes and scripts here -->
</body>
</html>
