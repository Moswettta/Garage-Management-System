<?php
// server.php

session_start();

// Initialize variables
$errors = array();

// Connect to the database
$db = mysqli_connect('localhost', 'username', 'password', 'barbdb');

// Employee login
if (isset($_POST['employeelogin'])) {
    // Get username and password from the form
    $ename = mysqli_real_escape_string($db, $_POST['ename']);
    $epassword = mysqli_real_escape_string($db, $_POST['epassword']);

    // Validate form
    if (empty($ename)) {
        array_push($errors, "Employee name is required");
    }
    if (empty($epassword)) {
        array_push($errors, "Password is required");
    }

    // If there are no errors, authenticate user
    if (count($errors) == 0) {
        $query = "SELECT * FROM employees WHERE ename='$ename' AND epassword='$epassword'";
        $result = mysqli_query($db, $query);

        if (mysqli_num_rows($result) == 1) {
            // Employee found
            $_SESSION['ename'] = $ename;
            header('location: index.php'); // Redirect to homepage or desired page
        } else {
            // Authentication failed
            array_push($errors, "Wrong username/password combination");
        }
    }
}

?>