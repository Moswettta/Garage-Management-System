<?php
// Replace 'localhost', 'root', '', and 'barbdb' with your actual database connection details
$db_host = 'localhost'; // Hostname
$db_user = 'root'; // Database username
$db_pass = ''; // Database password
$db_name = 'barbdb'; // Database name

// Create connection
$db = new mysqli($db_host, $db_user, $db_pass, $db_name);

// Check connection
if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}
?>
