<?php
// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "barbdb";

try {
    // Create a PDO instance
    $pdo = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    // Set the PDO error mode to exception
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    // Display error message if connection fails
    echo "Connection failed: " . $e->getMessage();
}

// Starting the session
session_start();

// Check if the form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST") {
    // Prepare a statement to fetch user details based on username
    $stmt = $pdo->prepare("SELECT * FROM members WHERE mname = :mname");
    $stmt->bindParam(":mname", $_POST['username']);
    
    // Attempt to execute the prepared statement
    try {
        $stmt->execute();
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // Verify if password matches
        if($user && password_verify($_POST['password'], $user['password'])) {
            // Password is correct, set session variables
            $_SESSION['mname'] = $user['mname'];
            $_SESSION['phone'] = $user['phone'];
            $_SESSION['email'] = $user['email'];
            
            // Redirect to member.php
            header("location: member.php");
            exit();
        } else {
            // Incorrect username or password
            echo "Incorrect username or password";
        }
    } catch(PDOException $e) {
        // Handle potential database connection errors
        echo "Error: " . $e->getMessage();
    }
}
?>
