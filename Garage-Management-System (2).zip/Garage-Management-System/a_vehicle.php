<!DOCTYPE html>
<html lang="en">
<head>
  <title>Add Item</title>
  <link rel="stylesheet" type="text/css" href="css/barbcss.css">
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <script src="https://kit.fontawesome.com/57c187a429.js" crossorigin="anonymous"></script>
  <?php include('includes/server.php'); ?>
  <?php include('includes/errors.php'); ?>
  <style>
    /* Sidebar styles */
    .sidebar {
      background-color: #f8f9fa;
      padding: 20px;
      border-right: 1px solid #dee2e6;
    }
    .sidebar .hdr {
      background-color: #047a94;
      color: white;
      padding: 10px 20px;
      font-weight: bold;
      font-size: 1.2em;
      margin-bottom: 15px;
    }
    .sidebar .linkb {
      display: block;
      color: #047a94;
      padding: 5px 20px;
      margin-bottom: 5px;
      text-decoration: none;
      transition: background-color 0.3s ease;
    }
    .sidebar .linkb:hover {
      background-color: #047a94;
      color: white;
    }
    /* Main content styles */
    .main-content {
      padding: 20px;
    }
  </style>
</head>
<body>
  <?php include('includes/adminnavbar.php');?>
  <div class="container-fluid">
    <div class="row justify-content-center" style="margin-top: 20px;">
      <div class="col-sm-3 sidebar">
        <div class="hdr">Admin Panel</div>
        <a href="a_bookingstoday.php" class="linkb">View Today's Bookings</a>
        <a href="a_bookings.php" class="linkb">View All Bookings</a>
        <a href="a_searchbookings.php" class="linkb">Search Completed Bookings</a>
        <a href="a_cancellations.php" class="linkb">View Cancelled Bookings</a>
        <a href="a_vehicle.php" class="linkb">Add or Delete Vehicle</a>
        <a href="a_employee.php" class="linkb">Add or Delete Employee</a>
        <a href="a_reviews.php" class="linkb">Analyze Reviews</a>
      </div>
      <div class="col-sm-2">&nbsp;</div>
      <div class="col-sm-3 main-content">
        <div class="header">
          <h2>Add Vehicle</h2>
        </div>
        <form method="POST">
          <div class="input-group">
            <label>Vehicle Make</label>
            <input type="text" name="vmake">
          </div>
          <div class="input-group">
            <label>Vehicle Model</label>
            <input type="text" name="vmodel">
          </div>
          <div class="input-group">
            <button type="submit" class="barbbutton" name="addvehicle">Add Vehicle</button>
          </div>
        </form>
      </div>
      <div class="col-sm-2">&nbsp;</div>
      <div class="col-sm-3 main-content">
        <div class="header">
          <h2>Delete Vehicle</h2>
        </div>
        <table class="table table-striped table-bordered table-sm">
          <?php
            $sql = "SELECT * FROM vehicles ORDER BY vmake";
            $result = $db->query($sql);

            if ($result->num_rows > 0) {
                echo "<tr><th>Make</th><th>Model</th><th>Actions</th></tr>";
                // output data of each row
                while($row = $result->fetch_assoc()) {
                    echo "<tr><td>" . $row["vmake"]. "</td><td>" . $row["vmodel"]. "</td><td><a href=\"a_vehicle.php?delvmake=" . $row['vmake'] . "&delvmodel=" .$row['vmodel'] . "\">Delete</a></td></tr>";
                }
            } else {
                echo "0 results";
            }
          ?>
        </table>
      </div>
    </div>
  </div>
</body>
</html>
