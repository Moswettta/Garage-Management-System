<?php
// Starting the session, necessary for using session variables
session_start();

// DBMS connection code -> hostname, username, password, database name
$db = mysqli_connect('localhost', 'root', '', 'barbdb');

// Fetch members data from the "members" table
$sql = "SELECT * FROM members";
$result = mysqli_query($db, $sql);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>View Members</title>
    <link rel="stylesheet" type="text/css" href="css/barbcss.css">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <script src="https://kit.fontawesome.com/57c187a429.js" crossorigin="anonymous"></script>
    <style>
        /* Sidebar styles */
        .sidebar {
            background-color: #f8f9fa;
            padding: 20px;
            border-right: 1px solid #dee2e6;
        }

        .sidebar .hdr {
            background-color: #047a94;
            color: white;
            padding: 10px 20px;
            font-weight: bold;
            font-size: 1.2em;
            margin-bottom: 15px;
        }

        .sidebar .linkb {
            display: block;
            color: #047a94;
            padding: 5px 20px;
            margin-bottom: 5px;
            text-decoration: none;
            transition: background-color 0.3s ease;
        }

        .sidebar .linkb:hover {
            background-color: #047a94;
            color: white;
        }

        /* Main content styles */
        .main-content {
            padding: 20px;
        }

        .member-list {
            margin-top: 20px;
            list-style-type: none;
            padding: 0;
        }

        .member-item {
            margin-bottom: 10px;
            padding: 10px;
            background-color: #f8f9fa;
            border-radius: 5px;
        }

        .member-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        .member-table th,
        .member-table td {
            border: 1px solid #dee2e6;
            padding: 8px;
            text-align: left;
        }

        .member-table th {
            background-color: #f8f9fa;
        }
    </style>
</head>
<body>
<?php include('includes/adminnavbar.php'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-sm-3">
            <div class="sidebar">
                <?php if(isset($_SESSION['ename'])): ?>
                    <a href="a_bookingstoday.php" class="linkb">View Today's Bookings</a>
                    <a href="a_bookings.php" class="linkb">View All Bookings</a>
                    <a href="a_searchbookings.php" class="linkb">Search Completed Bookings</a>
                    <a href="a_cancellations.php" class="linkb">View Cancelled Bookings</a>
                    <a href="a_vehicle.php" class="linkb">Add or Delete Vehicle</a>
                    <a href="a_employee.php" class="linkb">Add or Delete Employee</a>
                    <a href="mechanic.php" class="linkb">Add or view mechanics</a>
                    <a href="a_reviews.php" class="linkb">Analyze Reviews</a>
                <?php endif; ?>
            </div>
        </div>
        <div class="col-sm-9">
            <div class="container">
                <h2>View Members</h2>
                <table class="member-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Phone</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        // Output data of each row
                        while($row = mysqli_fetch_assoc($result)) {
                            echo "<tr>";
                            echo "<td>".$row["mid"]."</td>";
                            echo "<td>".$row["mname"]."</td>";
                            echo "<td>".$row["email"]."</td>";
                            echo "<td>".$row["phone"]."</td>";
                            echo "</tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>
