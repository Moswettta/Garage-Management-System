<?php
session_start();
include 'db.php'; // Include database connection

// Mechanic Authentication
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM mechanic WHERE email='$email' AND password='$password'";
    $result = $db->query($sql);

    if ($result->num_rows == 1) {
        // Mechanic found, set session variables and redirect to dashboard
        $row = $result->fetch_assoc();
        $_SESSION['mechanic_id'] = $row['id'];
        $_SESSION['mechanic_name'] = $row['name'];
        header("location: mechanic_dashboard.php");
        exit;
    } else {
        // Mechanic not found, display error message
        $error = "Invalid email or password.";
    }
}

// Mechanic Login Page
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Bootstrap CSS -->
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <title>Mechanic Login</title>
  <style>
    body {
      background-color: #f8f9fa;
    }
    .container {
      max-width: 400px;
      margin-top: 100px;
      background-color: #fff;
      padding: 20px;
      border-radius: 5px;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
    }
    .container h2 {
      margin-bottom: 20px;
    }
    .form-group {
      margin-bottom: 20px;
    }
    .btn-primary {
      width: 100%;
    }
    .alert {
      margin-top: 20px;
    }
  </style>
</head>
<body>
    <?php include('includes/navbar.php'); ?>
  <div class="container">
    <h2 class="text-center">Mechanic Login</h2>
    <form method="post">
      <div class="form-group">
        <label for="email">Email:</label>
        <input type="email" class="form-control" id="email" name="email" required>
      </div>
      <div class="form-group">
        <label for="password">Password:</label>
        <input type="password" class="form-control" id="password" name="password" required>
      </div>
      <button type="submit" class="btn btn-primary">Login</button>
    </form>
    <?php if (isset($error)) { ?>
      <div class="alert alert-danger mt-3" role="alert">
        <?php echo $error; ?>
      </div>
    <?php } ?>
  </div>
</body>
</html>
