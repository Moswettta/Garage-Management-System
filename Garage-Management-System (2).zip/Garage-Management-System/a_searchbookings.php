<!doctype html>
<html lang="en">
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Bootstrap CSS -->
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <link href="css/barbcss.css" rel="stylesheet">
  <title>View Bookings</title>
  <script src="https://kit.fontawesome.com/57c187a429.js" crossorigin="anonymous"></script>
  <?php include('includes/server.php');?>
  <?php include('includes/errors.php');?>
    <style>
    /* Sidebar styles */
    .sidebar {
      background-color: #f8f9fa;
      padding: 20px;
      border-right: 1px solid #dee2e6;
    }
    .sidebar .hdr {
      background-color: #047a94;
      color: white;
      padding: 10px 20px;
      font-weight: bold;
      font-size: 1.2em;
      margin-bottom: 15px;
    }
    .sidebar .linkb {
      display: block;
      color: #047a94;
      padding: 5px 20px;
      margin-bottom: 5px;
      text-decoration: none;
      transition: background-color 0.3s ease;
    }
    .sidebar .linkb:hover {
      background-color: #047a94;
      color: white;
    }
    /* Main content styles */
    .main-content {
      padding: 20px;
    }
    body {
     
      background-color: grey; /* Ensure container background is transparent */
    }
  </style>
</head>
<body>
  <?php include('includes/adminnavbar.php'); ?>
  <div class="container-fluid">
    <div class="row" style="margin: 15px;">
      <div class="col-sm-3 sidebar">
        <p class="hdr">Admin Panel</p>
        <a href="a_bookingstoday.php" class="linkb">View Today's Bookings</a>
        <a href="a_bookings.php" class="linkb">View All Bookings</a>
        <a href="a_searchbookings.php" class="linkb">Search Completed Bookings</a>
        <a href="a_cancellations.php" class="linkb">View Cancelled Bookings</a>
        <a href="a_vehicle.php" class="linkb">Add or Delete Vehicle</a>
        <a href="a_employee.php" class="linkb">Add or Delete Employee</a>
        <a href="a_reviews.php" class="linkb">Analyze Reviews</a>
      </div>
      <div class="col-sm-9 main-content">
        <div class="row justify-content-center" style="margin: 15px;">
          <h3 align="center" style="margin-bottom: 40px;">Search Bookings</h3>
          <div class="col-sm-6">
            <form action="a_searchedbookings.php" method="post">
              <div class="input-group mb-3">
                <span class="input-group-text">Enter date to search:</span>
                <input type="date" class="form-control" name="searchdate">
                <button class="btn btn-primary" type="submit" name="searchbookings">Search</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- Option 1: Bootstrap Bundle with Popper -->
  <script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>
