<!DOCTYPE html>
<html lang="en">
<head>
  <title>Garage Management System Admin Panel</title>
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <link href="css/barbcss.css" rel="stylesheet">
  <script src="https://kit.fontawesome.com/57c187a429.js" crossorigin="anonymous"></script>
  <?php include('includes/server.php'); ?>
  <?php include('includes/errors.php'); ?>
  <style>
 .sidebar {
      background-color: #f8f9fa;
      padding: 20px;
      border-right: 1px solid #dee2e6;
    }

     .sidebar .hdr {
      background-color: #047a94;
      color: white;
      padding: 10px 20px;
      font-weight: bold;
      font-size: 1.2em;
      margin-bottom: 15px;
    }
    .sidebar .linkb {
      display: block;
      color: #047a94;
      padding: 5px 20px;
      margin-bottom: 5px;
      text-decoration: none;
      transition: background-color 0.3s ease;
    }
    .sidebar .linkb:hover {
      background-color: #047a94;
      color: white;
    }
    /* Main content styles */
    .main-content {
      padding: 20px;
    }
  
    body {
      background-image: url('garage.jpeg'); /* Replace 'garage.jpeg' with your image path */
      background-size: cover;
      background-repeat: no-repeat;
    }
    .container-fluid {
      background-color: transparent; /* Ensure container background is transparent */
    }
    .login-form {
      background-color: white;
      padding: 20px;
      border-radius: 5px;
    }
    .login-form label {
      display: block;
      margin-bottom: 10px;
    }
    .login-form input[type="text"],
    .login-form input[type="password"] {
      width: 100%;
      padding: 10px;
      margin-bottom: 20px;
      border: 1px solid #ccc;
      border-radius: 5px;
    }
    .login-form button {
      background-color: #047a94;
      color: white;
      padding: 10px 20px;
      border: none;
      border-radius: 5px;
      cursor: pointer;
    }
    .login-form button:hover {
      background-color: #035e75;
    }
  </style>
</head>

<body>
    <?php include('includes/adminnavbar.php'); ?>
    <div class="container-fluid">
    <div class="row justify-content-right">
      <div class="col-sm-4">
        <div class="sidebar">
          
          <?php if(isset($_SESSION['ename'])): ?>

              <a href="dashboar.php" class="linkb">Dashoard</a><br>

            <a href="a_bookingstoday.php" class="linkb">View Today's Bookings</a><br>
            <a href="a_bookings.php" class="linkb">View All Bookings</a><br>
            <a href="a_searchbookings.php" class="linkb">Search Completed Bookings</a><br>
            <a href="a_cancellations.php" class="linkb">View Cancelled Bookings</a><br>

            <a href="a_vehicle.php" class="linkb">Add or Delete Vehicle</a><br>
            <a href="a_employee.php" class="linkb">Add or Delete Employee</a><br>
            <a href="addmember.php" class="linkb">Veiw</a><br>
            <a href="addmember.php" class="linkb"></a>Add member<br>
            <a href="mechanic.php" class="linkb">Add or veiw mechanics</a><br>
            <a href="a_reviews.php" class="linkb">Analyze Reviews</a><br>
             <a href="addmember.php" class="linkb">ADD</a><br>
             <a href="assign_mechanic.php" class="linkb"></a>assingn<br>



            

          <?php endif; ?>
        </div>
      </div>
      <div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-sm-4" style="background-color: #f0f0f0;">
            <!-- Content goes here -->
          <?php if(!isset($_SESSION['ename']) && !isset($_SESSION['mname'])): ?>
            <div class="login-form">
              <div class="row justify-content-right">
              <h3>Admin Log In</h3><br>
              <form method="post">
<label for="ename">Name</label>
<input type="text" placeholder="Enter Employee Name" name="ename" required>

                <label for="epassword">Password</label>
                <input type="password" placeholder="Enter Password" name="epassword" required>
                <button type="submit" name="employeelogin">Login</button>
              </form>
            </div>
          <?php endif; ?>
          <?php if(isset($_SESSION['mname'])): ?>
            Logged in as customer.
          <?php endif; ?>
        </div>
      </div>
    </div>
    </div>

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>
