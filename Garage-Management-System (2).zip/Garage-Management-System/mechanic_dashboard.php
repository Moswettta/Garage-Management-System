<?php
session_start();
include 'db.php'; // Include database connection

// Check if mechanic is logged in
if (!isset($_SESSION['mechanic_id'])) {
    header("Location: mechanic_login.php");
    exit();
}

$mechanic_id = $_SESSION['mechanic_id'];

$sql = "SELECT * FROM archive WHERE mechanic_id = $mechanic_id";
$result = $db->query($sql);

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Bootstrap CSS -->
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <title>Mechanic Dashboard</title>
  <style>
    body {
      background-color: #f8f9fa;
    }
    .container {
      max-width: 800px;
      margin-top: 50px;
      background-color: #fff;
      padding: 20px;
      border-radius: 10px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }
    h2 {
      text-align: center;
      margin-bottom: 20px;
    }
    table {
      width: 100%;
      border-collapse: collapse;
    }
    th, td {
      padding: 10px;
      border-bottom: 1px solid #dee2e6;
    }
    th {
      background-color: #f8f9fa;
      color: #495057;
      font-weight: bold;
    }
    td {
      color: #495057;
    }
    .no-bookings {
      text-align: center;
      color: #6c757d;
    }
  </style>
</head>
<body>
  <?php include('includes/mechanic_navbar.php'); ?>
  <div class="container">
    <h2>Assigned Bookings</h2>
    <table class="table table-striped">
      <thead>
        <tr>
          <th>Booking ID</th>
          <th>Name</th>
          <th>Phone</th>
          <th>Email</th>
          <th>Servicing Date</th>
          <th>Drop-off Time</th>
          <th>Vehicle</th>
          <th>Status</th>
        </tr>
      </thead>
      <tbody>
        <?php
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $row["bid"] . "</td>";
                echo "<td>" . $row["mname"] . "</td>";
                echo "<td>" . $row["phone"] . "</td>";
                echo "<td>" . $row["email"] . "</td>";
                echo "<td>" . $row["sdate"] . "</td>";
                echo "<td>" . $row["dtime"] . "</td>";
                echo "<td>" . $row["vehicle"] . "</td>";
                echo "<td>" . $row["status"] . "</td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='8' class='no-bookings'>No bookings assigned yet.</td></tr>";
        }
        ?>
      </tbody>
    </table>
  </div>
</body>
</html>
