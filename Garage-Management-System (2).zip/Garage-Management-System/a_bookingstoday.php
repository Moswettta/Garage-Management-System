<!doctype html>
<html lang="en">
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Bootstrap CSS -->
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <link href="css/barbcss.css" rel="stylesheet">
  <title>View Bookings</title>
  <script src="https://kit.fontawesome.com/57c187a429.js" crossorigin="anonymous"></script>
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/jq-3.6.0/dt-1.12.1/datatables.min.css"/>
  <?php include('includes/server.php');?>
  <?php include('includes/errors.php');?>
  <style>
    /* Sidebar styles */
    .sidebar {
      background-color: #f8f9fa;
      padding: 20px;
      border-right: 1px solid #dee2e6;
    }
    .sidebar .hdr {
      background-color: #047a94;
      color: white;
      padding: 10px 20px;
      font-weight: bold;
      font-size: 1.2em;
      margin-bottom: 15px;
    }
    .sidebar .linkb {
      display: block;
      color: #047a94;
      padding: 5px 20px;
      margin-bottom: 5px;
      text-decoration: none;
      transition: background-color 0.3s ease;
    }
    .sidebar .linkb:hover {
      background-color: #047a94;
      color: white;
    }
    /* Main content styles */
    .main-content {
      padding: 20px;
    }
  </style>
</head>
<body>
  <?php include('includes/adminnavbar.php'); ?>
  <div class="container-fluid">
    <div class="row" style="margin: 15px;">
      <div class="col-sm-3 sidebar">
        <?php
        if(isset($_SESSION['ename'])){
          ?>
          <p class="hdr">Admin Panel</p>
          <a href="a_bookingstoday.php" class="linkb">View Today's Bookings</a>
          <a href="a_bookings.php" class="linkb">View All Bookings</a>
          <a href="a_searchbookings.php" class="linkb">Search Completed Bookings</a>
          <a href="a_cancellations.php" class="linkb">View Cancelled Bookings</a>
          <a href="a_vehicle.php" class="linkb">Add or Delete Vehicle</a>
          <a href="a_employee.php" class="linkb">Add or Delete Employee</a>
          <a href="a_reviews.php" class="linkb">Analyze Reviews</a>
          <?php
        }
        ?>
      </div>
      <div class="col-sm-9 main-content">
        <h3 align="center" style="margin-bottom: 40px;">Today's Bookings</h3>
        <table id="table_id" class="display">
          <?php
            $todaydate=date("Y-m-d");
            $sql = "SELECT * FROM bookings WHERE sdate='$todaydate'";
            $result = $db->query($sql);

            if ($result->num_rows > 0) {
                echo "<thead><tr><th>ID</th><th>Name</th><th>Phone</th><th>Email</th><th>Servicing Date</th><th>Drop-off Time</th><th>Vehicle</th><th>Vehicle Number</th><th>Services Required</th><th>Comments</th><th>Status</th><th>Actions</th><th></th><th></th></tr></thead><tbody>";
                // output data of each row
                while($row = $result->fetch_assoc()) {
                    echo "<tr><td>" . $row["bid"]. "</td><td>" . $row["mname"]. "</td><td>" . $row["phone"]. "</td><td>" . $row["email"] . "</td><td>" . $row["sdate"] . "</td><td>" . $row["dtime"] . "</td><td>" . $row["vehicle"] . "</td><td>" . $row["vehiclenum"] . "</td><td>" . $row["services"] . "</td><td>" . $row["comments"] . "</td><td>" . $row["status"] . "</td><td><a href=\"a_bookingstoday.php?servicestatus=" . $row['bid'] . "\">Start</a></td><td><a href=\"a_bookingstoday.php?servicecompleted=" . $row['bid'] . "\">Complete</a></td><td><a href=\"a_bookingstoday.php?servicecancelled=" . $row['bid'] . "\">Cancel</a></td></tr>";
                }
            } else {
                echo "0 results";
            }
          ?>
        </tbody>
        </table>
      </div>
    </div>
  </div>
  <!-- Option 1: Bootstrap Bundle with Popper -->
  <script src="js/bootstrap.bundle.min.js"></script>
  <script type="text/javascript" src="https://cdn.datatables.net/v/dt/jq-3.6.0/dt-1.12.1/datatables.min.js"></script>
  <script type="text/javascript">
    $(document).ready( function () {
        $('#table_id').DataTable();
    } );
  </script>
</body>
</html>
