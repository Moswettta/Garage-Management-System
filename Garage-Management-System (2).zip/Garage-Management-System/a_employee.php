<!DOCTYPE html>
<html lang="en">
<head>
  <title>Add Employee</title>
  <link rel="stylesheet" href="css/barbcss.css">
  <script src="https://kit.fontawesome.com/57c187a429.js" crossorigin="anonymous"></script>
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <?php include('includes/server.php'); ?>
  <?php include('includes/errors.php'); ?>
  <style>
    /* Sidebar styles */
    .sidebar {
      background-color: #f8f9fa;
      padding: 20px;
      border-right: 1px solid #dee2e6;
    }
    .sidebar .hdr {
      background-color: #047a94;
      color: white;
      padding: 10px 20px;
      font-weight: bold;
      font-size: 1.2em;
      margin-bottom: 15px;
    }
    .sidebar .linkb {
      display: block;
      color: #047a94;
      padding: 5px 20px;
      margin-bottom: 5px;
      text-decoration: none;
      transition: background-color 0.3s ease;
    }
    .sidebar .linkb:hover {
      background-color: #047a94;
      color: white;
    }
    /* Main content styles */
    .main-content {
      padding: 20px;
    }
  </style>
</head>
<body>
  <?php include('includes/adminnavbar.php');?>
  <div class="container-fluid">
    <div class="row justify-content-center" style="margin-top: 20px;">
      <div class="col-sm-3 sidebar">
        <div class="hdr">Admin Panel</div>
        <a href="a_bookingstoday.php" class="linkb">View Today's Bookings</a>
        <a href="a_bookings.php" class="linkb">View All Bookings</a>
        <a href="a_searchbookings.php" class="linkb">Search Completed Bookings</a>
        <a href="a_cancellations.php" class="linkb">View Cancelled Bookings</a>
        <a href="a_vehicle.php" class="linkb">Add or Delete Vehicle</a>
        <a href="a_employee.php" class="linkb">Add or Delete Employee</a>
        <a href="a_reviews.php" class="linkb">Analyze Reviews</a>
      </div>
      <div class="col-sm-2">&nbsp;</div>
      <div class="col-sm-3 main-content">
        <div class="header">
          <h2>Add Employee</h2>
        </div>
        <form method="POST">
          <div class="input-group">
            <label>Employee Name</label>
            <input type="text" name="ename">
          </div>
          <div class="input-group">
            <label>Employee Phone Number</label>
            <input type="text" name="ephone">
          </div>
          <div class="input-group">
            <label>Employee Password</label>
            <input type="password" name="epassword">
          </div>
          <div class="input-group">
            <button type="submit" class="barbbutton" name="addemployee">Add Employee</button>
          </div>
        </form>
      </div>
      <div class="col-sm-2">&nbsp;</div>
      <div class="col-sm-3 main-content">
        <div class="header">
          <h2>Delete Employee</h2>
        </div>
        <table class="table table-striped table-bordered">
          <?php
            $sql = "SELECT * FROM employees";
            $result = $db->query($sql);

            if ($result->num_rows > 0) {
                echo "<tr><th>Name</th><th>Phone</th><th>Actions</th></tr>";
                // output data of each row
                while($row = $result->fetch_assoc()) {
                    echo "<tr><td>" . $row["ename"]. "</td><td>" . $row["ephone"]. "</td><td><a href=\"a_employee.php?delemp=" . $row['eid'] . "\">Delete</a></td></tr>";
                }
            } else {
                echo "0 results";
            }
          ?>
        </table>
      </div>
    </div>
  </div>
  <!-- Option 1: Bootstrap Bundle with Popper -->
  <script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>
